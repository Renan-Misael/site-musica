# Harmonia Academy

Site de educação musical (HTML + CSS + JS).

## Como abrir

Abra o arquivo **index.html** no navegador (duplo clique).

É um único arquivo completo — não precisa de terminal nem de servidor.

## O que tem no site

- Teoria musical (quizzes)
- Biblioteca de partituras com transposição e PDF
- Metrônomo
- Formulário de inscrição (só no navegador)
